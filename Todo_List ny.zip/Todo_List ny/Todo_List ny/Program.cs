﻿using System;
using System.Collections.Generic;
using System.IO;

namespace calculate_sum_2
{
    class Program
    {
        public static void Main(string[] args)
        {
            while (true)
            {
                try
                {
                    Console.WriteLine("Todo-List team(A) type 1 \nTodo-List team(B) type 2");
                    int ee = int.Parse(Console.ReadLine());

                
                    if (ee == 1)
                    {
                        Progect.TeamA.ClassA.print();
                    }
                    else if (ee == 2)
                    {
                        Progect.TeamB.ClassA.print();
                    }
                  
                    else
                    {
                        Console.WriteLine("Please enter a correct number\nTry again");
                        continue;
                    }
                }
                catch (Exception ex)
                {

                    Console.WriteLine("Please enter a correct number\nTry again" +ex);
                    continue;
                }

            }

        }

    }
}
namespace Progect
{
    namespace TeamA
    {
        class ClassA
        {
            static readonly string filename1 = @"teamA.text";
            public static void print()
            {
                int menuItem = -1;
                while (menuItem != 0)
                {
                    menuItem = menu();
                    switch (menuItem)
                    {
                        case 1:
                            AddItem();
                            break;
                        case 2:
                            ShowList();
                            break;
                        case 3:
                            RemoveItem();
                            break;
                        case 4:
                            Progect.TeamB.ClassA.print();
                            break;
                        case 0:
                            Console.WriteLine("Thank you and welcom backa");
                            break;
                        default:
                            Console.WriteLine("Dont recognlize input");
                            break;

                    }
                }
            }
            static void AddItem()
            {
                Console.WriteLine("Add Item");
                StreamWriter outFile = File.AppendText(filename1);
                Console.Write("Enter an item: ");
                string item = Console.ReadLine();
                outFile.WriteLine(item);
                outFile.Close();
            }
            static void RemoveItem()
            {
                int choice;
                ShowList();
                Console.Write("Which item do you want to remove? ");
                choice = Convert.ToInt32(Console.ReadLine());
                List<string> items = new List<string>();
                int number = 1;
                string item;
                StreamReader inFile = new StreamReader(filename1);
                while (inFile.Peek() != -1)
                {
                    item = inFile.ReadLine();
                    if (number != choice)
                        items.Add(item);
                    ++number;
                }
                inFile.Close();
                StreamWriter outFile = new StreamWriter(filename1);
                for (int i = 0; i < items.Count; i++)
                    outFile.WriteLine(items[i]);
                outFile.Close();

            }
            static int menu()
            {
                int choice;
                Console.WriteLine("\nWelcom to Todo-List Team A");
                Console.WriteLine("\t1.Add item to-do list");
                Console.WriteLine("\t2.Show to-do list");
                Console.WriteLine("\t3.Remove item from to-do list");
                Console.WriteLine("\t4.Change to Team B");
                Console.WriteLine("\t0.Exit the program and go back to start!");
                Console.WriteLine();
                Console.WriteLine("Enter your choice :");
                choice = Convert.ToInt32(Console.ReadLine());
                return choice;
            }
            static void ShowList()
            {
                Console.WriteLine("\nTo-do List : ");
                using (var inFile = new StreamReader(filename1))
                {
                    string line;
                    int number = 1;
                    while (inFile.Peek() != -1)
                    {
                        line = inFile.ReadLine();
                        Console.Write(number + " ");
                        Console.WriteLine(line);
                        ++number;
                    }
                    Console.WriteLine();
                    inFile.Close();
                }
            }
        }
    }
}
namespace Progect
{
    namespace TeamB
    {
        class ClassA
        {
            static readonly string filename = @"teamB.text";
            public static void print()
            {
                int menuItem = -1;
                while (menuItem != 0)
                {
                    menuItem = menu();
                    switch (menuItem)
                    {
                        case 1:
                            AddItem();
                            break;
                        case 2:
                            ShowList();
                            break;
                        case 3:
                            RemoveItem();
                            break;
                        case 4:
                            Progect.TeamA.ClassA.print();
                            break;
                        case 0:
                            Console.WriteLine("Thank you and welcom backa");
                            break;
                        default:
                            Console.WriteLine("Dont recognlize input");
                            break;

                    }
                }
            }
            static void AddItem()
            {
                Console.WriteLine("Add Item");
                StreamWriter outFile = File.AppendText(filename);
                Console.Write("Enter an item: ");
                string item = Console.ReadLine();
                outFile.WriteLine(item);
                outFile.Close();
            }
            static void RemoveItem()
            {
                int choice;
                ShowList();
                Console.Write("Which item do you want to remove? ");
                choice = Convert.ToInt32(Console.ReadLine());
                List<string> items = new List<string>();
                int number = 1;
                string item;
                StreamReader inFile = new StreamReader(filename);
                while (inFile.Peek() != -1)
                {
                    item = inFile.ReadLine();
                    if (number != choice)
                        items.Add(item);
                    ++number;
                }
                inFile.Close();
                StreamWriter outFile = new StreamWriter(filename);
                for (int i = 0; i < items.Count; i++)
                    outFile.WriteLine(items[i]);
                outFile.Close();

            }
            static int menu()
            {
                int choice;
                Console.WriteLine("\nWelcom to Todo-List Team B");
                Console.WriteLine("\t1.Add item to-do list");
                Console.WriteLine("\t2.Show to-do list");
                Console.WriteLine("\t3.Remove item from to-do list");
                Console.WriteLine("\t4.Change to Team A");
                Console.WriteLine("\t0.Exit the program and go back to start!");
                Console.WriteLine();
                Console.WriteLine("Enter your choice :");
                choice = Convert.ToInt32(Console.ReadLine());
                return choice;
            }
            static void ShowList()
            {
                Console.WriteLine("\nTo-do List : ");
                using (var inFile = new StreamReader(filename))
                {
                    string line;
                    int number = 1;
                    while (inFile.Peek() != -1)
                    {
                        line = inFile.ReadLine();
                        Console.Write(number + " ");
                        Console.WriteLine(line);
                        ++number;
                    }
                    Console.WriteLine();
                    inFile.Close();
                }
            }
        }
    }
}